const express = require('express');
const bookModel = require('../model/book_model');

const router = express.Router();


router.get('/books', async (req, res) => {
    const bookList = await bookModel.find();
    console.log(bookList);
    res.status(200).send(bookList);
});


router.get('/books/:id', async (req, res) => {
    const { id } = req.params;
    const book = await bookModel.findOne({isbn: id});
    if(!book)return (res.send("Book Not Found!"));
    res.status(200).send(book);
})


router.post('/books', async (req, res) => {
    const title = req.body.title;
    const isbn = req.body.isbn;
    const author = req.body.author;

    const bookExist = await bookModel.findOne({isbn : isbn});

    if(bookExist)return (res.send("Book already Exist!"));

    var data = await bookModel.create({title,isbn,author});
    data.save();

    res.status(201).send("Book uploaded")
})


router.put('/books/:id', async (req, res) => {
    const { id } = req.params;

    const {
        title,
        author
    } = req.body;

    const bookExist = await bookModel.findOne({isbn : id});

    if(!bookExist)return (res.send("Book does not Exist!"));

    const updateField = (val, prev) => (!val)? prev : val;

    const updatedBook = {
        ...bookExist,
        title: updateField(title, bookExist.title),
        author: updateField(title, bookExist.author)
    };

    await bookModel.updateOne({isbn : id}, {$set :{title: updatedBook.title, author:updatedBook.author}});

    res.status(200).send("Book updated successfully");
});


router.delete('/books/:id', async (req, res) => {
    const { id }  = req.params;

    const bookExist = await bookModel.findOne({isbn:id});
    if(!bookExist) return (res.status(404).send("Book not found"));

    await bookModel.deleteOne({isbn : id});
    res.status(204).send("Book deleted successfully!");
});

module.exports = router;